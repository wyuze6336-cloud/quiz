#!/usr/bin/env bash
set -euo pipefail
mkdir -p "$HOME/glimmer-q7"
cd "$HOME/glimmer-q7"
cat /etc/fedora-release
uname -m
if ! command -v docker >/dev/null; then
  sudo dnf config-manager addrepo --from-repofile https://download.docker.com/linux/fedora/docker-ce.repo
  sudo dnf install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
fi
sudo systemctl start docker
sudo docker --version
sudo docker ps -a
