CREATE DATABASE IF NOT EXISTS campus_library CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE campus_library;
CREATE TABLE IF NOT EXISTS books (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 isbn VARCHAR(20),
 title VARCHAR(200) NOT NULL,
 author VARCHAR(100) NOT NULL,
 publisher VARCHAR(100),
 published_on DATE,
 price DECIMAL(10,2) NOT NULL CHECK(price >= 0),
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
-- 每行代表馆藏的一册书，ISBN 可重复，id 唯一。
INSERT INTO books(isbn,title,author,publisher,published_on,price) VALUES
 ('demo-001','Java学习笔记','示例作者甲','示例出版社','2024-01-01',59.90),
 ('demo-002','网络基础','示例作者乙','示例出版社','2024-03-01',45.00),
 ('demo-001','Java学习笔记','示例作者甲','示例出版社','2024-01-01',59.90);
SET @last_id=LAST_INSERT_ID();
SELECT * FROM books ORDER BY id;
SELECT * FROM books WHERE id=@last_id;
UPDATE books SET price=49.90 WHERE id=@last_id;
SELECT * FROM books WHERE id=@last_id;
DELETE FROM books WHERE id=@last_id+1;
SELECT * FROM books ORDER BY id;
