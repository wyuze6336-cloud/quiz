#!/usr/bin/env bash
set -euo pipefail
cd "$HOME/glimmer-q7"
case "${1:-}" in
 baidu)
  curl --http1.1 --max-time 30 -sS -v https://www.baidu.com -o baidu.html 2> baidu-request.txt
  cat baidu-request.txt
  head -c 500 baidu.html; echo
  ;;
 header)
  curl --http1.1 --max-time 30 -sS -v -H 'Student-Name: wuyuze' https://www.baidu.com -o baidu-header.html 2> baidu-header.txt
  sed -n '/^> /p; /^< /p' baidu-header.txt
  ;;
 text)
  curl --http1.1 --max-time 30 -sS -i -X POST https://httpbin.org/post -H 'Content-Type: text/plain' --data 'hello http'
  ;;
 json)
  curl --http1.1 --max-time 30 -sS -i -X POST https://httpbin.org/post -H 'Content-Type: application/json' --data '{"username":"Tom","age":18}'
  ;;
 config)
  # 实际执行的请求命令；响应保存为文件供下一步展示。
  set -x
  curl --http1.1 --max-time 30 -sS -i -X POST https://httpbin.org/post \
    -H 'Content-Type: application/json' -H 'X-Student-Name: wuyuze' \
    --data '{"username":"admin","password":"123456"}' > login-response.txt
  set +x
  ;;
 response) cat login-response.txt ;;
 *) echo '用法：bash http-lab.sh baidu|header|text|json|config|response';;
esac
