#!/usr/bin/env bash
# 仅限题目专用本地练习容器；逐条执行、确认结果后再做下一步。
set -euo pipefail
mkdir -p "$HOME/mysql_data"
docker pull mysql:8.0
docker run -d --name glimmer-q7-mysql \
  -e MYSQL_ROOT_PASSWORD=123456 -e MYSQL_DATABASE=user_db \
  -p 127.0.0.1:3306:3306 -v "$HOME/mysql_data:/var/lib/mysql:Z" mysql:8.0
echo '等待初始化完成，使用下列命令检查：'
echo 'docker logs glimmer-q7-mysql'
echo 'docker exec -it glimmer-q7-mysql mysql -uroot -p user_db'
# 在 mysql 客户端输入：
# CREATE TABLE users(id BIGINT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(80) NOT NULL);
# INSERT INTO users(name) VALUES ('Persistence demo');
# SELECT * FROM users;
# exit
# 保存截图后，只删除刚创建的练习容器，不删除宿主机数据：
# docker rm -f glimmer-q7-mysql
# 然后重复上面的 docker run 命令并重新 SELECT * FROM users;
