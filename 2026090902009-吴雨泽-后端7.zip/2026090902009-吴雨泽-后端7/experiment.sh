#!/usr/bin/env bash
set -euo pipefail
cd "$HOME/glimmer-q7"
case "${1:-}" in
 hello)
  sudo docker run --rm hello-world
  sudo docker run -d --name glimmer-q7-web -p 127.0.0.1:8080:80 nginx:alpine
  sudo docker ps
  curl -sI http://127.0.0.1:8080
  ;;
 stop)
  sudo docker stop glimmer-q7-web
  sudo docker ps -a
  ;;
 mysql)
  if test -d "$HOME/mysql_data" && test -n "$(ls -A "$HOME/mysql_data" 2>/dev/null)"; then
    echo 'mysql_data 已有数据，请先检查，不会自动覆盖。';exit 1
  fi
  mkdir -p "$HOME/mysql_data"
  sudo docker pull mysql:8.0
  sudo docker run -d --name glimmer-q7-mysql \
    -e MYSQL_ROOT_PASSWORD=123456 -e MYSQL_DATABASE=user_db \
    -p 127.0.0.1:3306:3306 -v "$HOME/mysql_data:/var/lib/mysql:Z" mysql:8.0
  ;;
 books)
  sudo docker exec -i glimmer-q7-mysql mysql -uroot -p123456 --default-character-set=utf8mb4 --table < books.sql
  ;;
 user)
  sudo docker exec -i glimmer-q7-mysql mysql -uroot -p123456 --table user_db <<'SQL'
CREATE TABLE users(id BIGINT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(80) NOT NULL);
INSERT INTO users(name) VALUES ('wuyuze');
SELECT * FROM users;
SQL
  sudo docker inspect glimmer-q7-mysql --format '{{range .Mounts}}{{.Source}} -> {{.Destination}}{{end}}'
  ;;
 rebuild)
  # 只删除刚创建的题目专用容器；宿主机 mysql_data 保留。
  sudo docker rm -f glimmer-q7-mysql
  sudo docker run -d --name glimmer-q7-mysql \
    -e MYSQL_ROOT_PASSWORD=123456 -e MYSQL_DATABASE=user_db \
    -p 127.0.0.1:3306:3306 -v "$HOME/mysql_data:/var/lib/mysql:Z" mysql:8.0
  ;;
 check)
  sudo docker exec glimmer-q7-mysql mysql -uroot -p123456 --table user_db -e 'SELECT * FROM users;'
  sudo docker ps
  ;;
 nginx)
  sudo docker run -d --name glimmer-q7-pineapple -p 127.0.0.1:8081:80 \
    -v "$PWD/index.html:/usr/share/nginx/html/index.html:ro,Z" \
    -v "$PWD/nginx.conf:/etc/nginx/nginx.conf:ro,Z" nginx:alpine
  sudo docker exec glimmer-q7-pineapple nginx -t
  curl -sI http://127.0.0.1:8081
  ;;
 *) echo '用法：bash experiment.sh hello|stop|mysql|books|user|rebuild|check|nginx';;
esac
