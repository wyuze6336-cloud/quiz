#!/usr/bin/env bash
# 题目测试数据，使用姓名拼音 wuyuze；逐条执行并观察实际响应。
curl -i https://www.baidu.com
curl -i https://www.baidu.com -H 'Student-Name: wuyuze'
curl -i https://httpbin.org/post -H 'Content-Type: text/plain' --data 'hello http'
curl -i https://httpbin.org/post -H 'Content-Type: application/json' --data '{"username":"Tom","age":18}'
curl -i https://httpbin.org/post -H 'Content-Type: application/json' \
  -H 'X-Student-Name: wuyuze' --data '{"username":"admin","password":"123456"}'
