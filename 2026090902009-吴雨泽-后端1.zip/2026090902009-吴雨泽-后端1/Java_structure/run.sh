#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p build
javac -encoding UTF-8 -d build \
  com/Example/HelloWorld.java com/Example/tool/Print.java
printf '无参数运行：\n'
java -cp build com.Example.HelloWorld
printf '\n传入三个参数：\n'
java -cp build com.Example.HelloWorld 111 222 333
