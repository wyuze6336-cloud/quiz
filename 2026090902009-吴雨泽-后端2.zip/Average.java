import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.math.*;
public class Average {
    public static class EmptyFileException extends Exception {
        public EmptyFileException(String message) { super(message); }
    }
    public static BigDecimal average(Path path) throws IOException, EmptyFileException {
        BigInteger sum = BigInteger.ZERO; long count = 0;
        try (BufferedReader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                count++;
                try { sum = sum.add(BigInteger.valueOf(Integer.parseInt(line.trim()))); }
                catch (NumberFormatException e) { throw new NumberFormatException("Invalid integer at line " + count); }
            }
        }
        if (count == 0) throw new EmptyFileException("File is empty");
        return new BigDecimal(sum).divide(BigDecimal.valueOf(count), MathContext.DECIMAL128);
    }
    public static void main(String[] args) {
        try { System.out.println("average=" + average(Paths.get(args.length == 0 ? "data.txt" : args[0]))); }
        catch (NoSuchFileException e) { System.err.println("File not found: " + e.getFile()); }
        catch (EmptyFileException | NumberFormatException e) { System.err.println(e.getMessage()); }
        catch (IOException e) { System.err.println("I/O error: " + e.getMessage()); }
    }
}
