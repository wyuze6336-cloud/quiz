import java.util.*;
import java.util.stream.Collectors;
public class Basics {
    public static boolean isLeapYear(int year) {
        return year % 400 == 0 || (year % 4 == 0 && year % 100 != 0);
    }
    public static void print(int n) {
        if (n <= 0 || n % 2 == 0) throw new IllegalArgumentException("n must be positive and odd");
        int mid = n / 2;
        for (int row = 0; row < n; row++) {
            int left = Math.abs(mid - row), right = n - 1 - left;
            StringBuilder line = new StringBuilder();
            for (int col = 0; col <= right; col++) line.append(col == left || col == right ? '*' : ' ');
            System.out.println(line);
        }
    }
    private static void checkN(int n) {
        if (n < 0 || n > 46) throw new IllegalArgumentException("int Fibonacci requires 0 <= n <= 46");
    }
    public static int fibonacci(int n) {
        checkN(n);
        return recursive(n, new int[n + 1]);
    }
    private static int recursive(int n, int[] memo) {
        if (n <= 1) return n;
        if (memo[n] == 0) memo[n] = recursive(n - 1, memo) + recursive(n - 2, memo);
        return memo[n];
    }
    public static int fibonacciIterative(int n) {
        checkN(n);
        if (n <= 1) return n;
        int a = 0, b = 1;
        for (int i = 2; i <= n; i++) { int next = a + b; a = b; b = next; }
        return b;
    }
    public static void hanoi(int n) {
        if (n < 0) throw new IllegalArgumentException("n must not be negative");
        move(n, 'A', 'B', 'C');
    }
    private static void move(int n, char from, char spare, char to) {
        if (n == 0) return;
        move(n - 1, from, to, spare);
        System.out.println(from + "->" + to);
        move(n - 1, spare, from, to);
    }
    static class Student {
        final String name; final int score;
        Student(String name, int score) { this.name = name; this.score = score; }
        String getName() { return name; } int getScore() { return score; }
    }
    public static void main(String[] args) {
        int a = 4; char c = '0'; System.out.println("4 + '0' = " + (a + c));
        a = 5; int b = 7; int result = (++a) + (b++);
        System.out.println(result); System.out.println(a + " " + b);
        System.out.println("1900=" + isLeapYear(1900) + ", 2000=" + isLeapYear(2000));
        print(5);
        System.out.println("fib(10)=" + fibonacci(10) + ", " + fibonacciIterative(10));
        hanoi(3);
        List<Student> students = Arrays.asList(new Student("Alice",85),new Student("Bob",58),
            new Student("Charlie",90),new Student("David",45),new Student("Eve",72),
            new Student("Frank",60),new Student("Grace",55),new Student("Heidi",95));
        List<String> passingStudents = students.stream().filter(s -> s.getScore() >= 60)
            .map(s -> s.getName().toUpperCase(Locale.ROOT)).sorted().collect(Collectors.toList());
        System.out.println(passingStudents);
    }
}
