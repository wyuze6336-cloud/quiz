import java.math.BigDecimal;
import java.util.*;
public class OopDemo {
    public static class Person {
        private String name; private int age; private int sex;
        private static int count;
        public Person(String name, int age, int sex) {
            this.name = Objects.requireNonNull(name); setAge(age); this.sex = sex; count++;
        }
        public Person(Person other) { this(other.name, other.age, other.sex); }
        public void setAge(int age) { if (age < 0) throw new IllegalArgumentException("negative age"); this.age = age; }
        public String getName() { return name; }
        public void eat() { System.out.println(name + "正在吃东西"); }
        public void sleep() { System.out.println(name + "正在睡觉"); }
        public void dadoudou() { System.out.println(name + "正在打豆豆"); }
        public static int getCount() { return count; }
    }
    public static class Animal {
        private final String name; private final int id;
        public Animal(String name, int id) { this.name = name; this.id = id; }
        public void eat() { System.out.println(name + "正在吃"); }
        public void sleep() { System.out.println(name + "正在睡"); }
        public void introduction() { System.out.println("大家好！我是" + id + "号" + name + "。"); }
    }
    public static class Penguin extends Animal {
        public Penguin(String name, int id) { super(name, id); }
        @Override public void eat() { System.out.println("企鹅吃鱼"); }
    }
    public static class Mouse extends Animal {
        public Mouse(String name, int id) { super(name, id); }
        @Override public void eat() { System.out.println("老鼠吃谷物"); }
    }
    public interface Shape { double area(); double perimeter(); }
    static double positive(double x) {
        if (!Double.isFinite(x) || x <= 0) throw new IllegalArgumentException("invalid length"); return x;
    }
    public static class Circle implements Shape {
        private final double r;
        public Circle(double r) { this.r = positive(r); }
        @Override public double area() { return Math.PI*r*r; }
        @Override public double perimeter() { return 2*Math.PI*r; }
    }
    public static class Rectangle implements Shape {
        private final double w,h;
        public Rectangle(double w,double h) { this.w=positive(w); this.h=positive(h); }
        @Override public double area() { return w*h; }
        @Override public double perimeter() { return 2*(w+h); }
    }
    public static class Triangle implements Shape {
        private final double a,b,c;
        public Triangle(double a,double b,double c) {
            this.a=positive(a); this.b=positive(b); this.c=positive(c);
            if (a+b<=c || a+c<=b || b+c<=a) throw new IllegalArgumentException("invalid triangle");
        }
        @Override public double area() { double s=perimeter()/2; return Math.sqrt(s*(s-a)*(s-b)*(s-c)); }
        @Override public double perimeter() { return a+b+c; }
    }
    // 单线程教学模型；金融生产系统还需认证、密码哈希、数据库事务与并发控制。
    public static class BankAccount {
        private final String accountNumber,accountHolder,password;
        private BigDecimal balance;
        public BankAccount(String number,String holder,double initial,String password) {
            if (!Double.isFinite(initial) || initial<0) throw new IllegalArgumentException("invalid balance");
            this.accountNumber=Objects.requireNonNull(number); this.accountHolder=Objects.requireNonNull(holder);
            this.password=Objects.requireNonNull(password); this.balance=BigDecimal.valueOf(initial);
        }
        public void deposit(double amount) {
            if (!validateAmount(amount)) throw new IllegalArgumentException("invalid amount");
            balance=balance.add(BigDecimal.valueOf(amount));
        }
        public boolean withdraw(double amount,String inputPassword) {
            if (!validatePassword(inputPassword) || !validateAmount(amount)) return false;
            BigDecimal money=BigDecimal.valueOf(amount);
            if (balance.compareTo(money)<0) return false;
            balance=balance.subtract(money); return true;
        }
        public boolean transfer(BankAccount recipient,double amount,String inputPassword) {
            if (recipient==null || recipient==this || !validatePassword(inputPassword) || !validateAmount(amount)) return false;
            BigDecimal money=BigDecimal.valueOf(amount);
            if (balance.compareTo(money)<0) return false;
            balance=balance.subtract(money); recipient.balance=recipient.balance.add(money); return true;
        }
        public double getBalance() { return balance.doubleValue(); }
        public String getAccountInfo() {
            String tail=accountNumber.substring(Math.max(0,accountNumber.length()-4));
            return "account=****"+tail+", holder="+(accountHolder.isEmpty()?"*":accountHolder.substring(0,1)+"*");
        }
        private boolean validatePassword(String input) { return password.equals(input); }
        private boolean validateAmount(double amount) { return Double.isFinite(amount) && amount>0; }
    }
    public static void main(String[] args) {
        Person p=new Person("小明",18,1), copy=new Person(p);
        copy.setAge(19); p.eat(); System.out.println("copies distinct="+(p!=copy)+", count="+Person.getCount());
        for(Animal a:Arrays.asList(new Penguin("企鹅",1),new Mouse("老鼠",2))) { a.introduction(); a.eat(); }
        for(Shape s:Arrays.asList(new Circle(2),new Rectangle(3,4),new Triangle(3,4,5)))
            System.out.printf(Locale.ROOT,"%s area=%.3f perimeter=%.3f%n",s.getClass().getSimpleName(),s.area(),s.perimeter());
        BankAccount a=new BankAccount("12345678","张三",100,"demo"), b=new BankAccount("87654321","李四",0,"demo2");
        a.deposit(20); System.out.println("transfer="+a.transfer(b,30,"demo"));
        System.out.println(a.getBalance()+" "+b.getBalance()+" "+a.getAccountInfo());
        if(a.withdraw(1,"wrong") || a.transfer(b,Double.NaN,"demo") || a.withdraw(1000,"demo")) throw new AssertionError();
    }
}
