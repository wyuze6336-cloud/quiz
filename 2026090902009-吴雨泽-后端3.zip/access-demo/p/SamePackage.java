package p;
public class SamePackage {
    public static int read(){Parent p=new Parent();return p.publicValue+p.protectedValue+p.packageValue;}
}
