package p;
public class Parent {
    public int publicValue=1;
    protected int protectedValue=2;
    int packageValue=3;
    private int privateValue=4;
    public int inside(){return publicValue+protectedValue+packageValue+privateValue;}
}
