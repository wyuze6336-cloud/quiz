package q;
public class Child extends p.Parent {
    public int read(){return this.publicValue+this.protectedValue;}
}
