package q;
public class Other {
    public static void main(String[] args){
        System.out.println(new p.Parent().publicValue);
        System.out.println(p.SamePackage.read());
        System.out.println(new Child().read());
    }
}
