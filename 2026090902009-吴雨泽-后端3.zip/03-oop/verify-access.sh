#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build build/negative-src build/negative
javac -encoding UTF-8 -d build src/*.java src/people/*.java src/access/*.java
for source in negative-tests/*.java.txt; do
    name=$(basename "${source%.txt}")
    cp "$source" "build/negative-src/$name"
    printf '\n检查 %s（预期访问权限错误）\n' "$name"
    if javac -encoding UTF-8 -cp build -d build/negative "build/negative-src/$name"; then
        printf '本应编译失败，却通过了：%s\n' "$name" >&2
        exit 1
    fi
done
printf '\n六组违规访问均被编译器拒绝。\n'
