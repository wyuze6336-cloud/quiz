public class Penguin extends Animal {
    public Penguin(String name, int id) {
        super(name, id);
    }

    @Override
    public void eat() {
        System.out.println(getName() + "是企鹅，正在吃鱼");
    }
}
