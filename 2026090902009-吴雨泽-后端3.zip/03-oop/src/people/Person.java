package people;

public class Person {
    private final String name;
    private int age;
    private final int sex;
    private static int count;

    public Person(String name, int age, int sex) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("姓名不能为空");
        }
        this.name = name;
        setAge(age);
        this.sex = sex;
        count++;
    }

    public Person(Person other) {
        this(other.name, other.age, other.sex);
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public int getSex() {
        return sex;
    }

    public void setAge(int age) {
        if (age < 0) {
            throw new IllegalArgumentException("年龄不能小于 0");
        }
        this.age = age;
    }

    public void printInfo() {
        System.out.printf("姓名=%s，年龄=%d，sex=%d%n", name, age, sex);
    }

    public void eat() {
        printAction("吃东西");
    }

    public void sleep() {
        printAction("睡觉");
    }

    public void dadoudou() {
        printAction("打豆豆");
    }

    private void printAction(String action) {
        System.out.println(name + "正在" + action);
    }

    // 这两个方法用于比较同包和跨包的访问范围。
    String packageDescription() {
        return name + "，" + age + "岁";
    }

    protected String protectedName() {
        return name;
    }

    public static int getCount() {
        return count;
    }
}
