package people;

public class SamePackageAccess {
    public static void show(Person person) {
        System.out.println("同包访问 public：" + person.getName());
        System.out.println("同包访问 protected：" + person.protectedName());
        System.out.println("同包访问默认权限：" + person.packageDescription());
    }
}
