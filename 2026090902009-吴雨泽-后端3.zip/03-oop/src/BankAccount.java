import java.util.Locale;

public class BankAccount {
    private final String accountNumber;
    private final String accountHolder;
    private double balance;
    private final String password;

    public BankAccount(String accountNumber, String accountHolder,
                       double initialBalance, String password) {
        if (accountNumber == null || accountNumber.isBlank()
                || accountHolder == null || accountHolder.isBlank()
                || password == null || password.isEmpty()) {
            throw new IllegalArgumentException("账号、姓名和密码不能为空");
        }
        if (!Double.isFinite(initialBalance) || initialBalance < 0) {
            throw new IllegalArgumentException("初始余额必须为有限非负数");
        }
        this.accountNumber = accountNumber;
        this.accountHolder = accountHolder;
        this.balance = initialBalance;
        this.password = password;
    }

    public void deposit(double amount) {
        if (!Double.isFinite(amount) || amount <= 0
                || !Double.isFinite(balance + amount)) {
            throw new IllegalArgumentException("存款金额必须为有限正数，余额不能溢出");
        }
        balance += amount;
    }

    public boolean withdraw(double amount, String inputPassword) {
        if (!password.equals(inputPassword)
                || !Double.isFinite(amount) || amount <= 0 || amount > balance) {
            return false;
        }
        balance -= amount;
        return true;
    }

    public boolean transfer(BankAccount recipient, double amount, String inputPassword) {
        if (recipient == null || recipient == this
                || !password.equals(inputPassword)
                || !Double.isFinite(amount) || amount <= 0 || amount > balance
                || !Double.isFinite(recipient.balance + amount)) {
            return false;
        }
        balance -= amount;
        recipient.balance += amount;
        return true;
    }

    public double getBalance() {
        return balance;
    }

    public String getAccountInfo() {
        String hiddenNumber = accountNumber.length() > 4
                ? "****" + accountNumber.substring(accountNumber.length() - 4) : "****";
        String hiddenHolder = accountHolder.length() > 1
                ? accountHolder.substring(0, 1) + "*" : "*";
        return String.format(Locale.ROOT, "账号=%s，户名=%s，余额=%.2f元",
                hiddenNumber, hiddenHolder, balance);
    }

    // 按题面“只需修改可见性”保留占位实现。
    // 实际密码和金额检查已写在上面的业务方法中。
    private boolean validatePassword(String inputPassword) {
        return true;
    }

    private boolean validateAmount(double amount) {
        return true;
    }
}
