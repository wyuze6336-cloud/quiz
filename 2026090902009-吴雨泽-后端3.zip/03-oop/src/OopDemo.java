import access.OtherPackageAccess;
import access.PersonChild;
import people.Person;
import people.SamePackageAccess;
import java.util.List;
import java.util.Locale;

public class OopDemo {
    public static void main(String[] args) {
        Person original = demonstratePerson();
        demonstrateAccess(original);
        demonstrateInheritance();
        demonstrateShapes();
        demonstrateAccounts();
    }

    private static Person demonstratePerson() {
        System.out.println("Task 1：Person 与复制构造");
        Person original = new Person("小明", 18, 1);
        Person copy = new Person(original);
        copy.setAge(19);
        System.out.print("原对象：");
        original.printInfo();
        System.out.print("副本：");
        copy.printInfo();
        System.out.println("两个不同对象：" + (original != copy));
        original.eat();
        original.sleep();
        original.dadoudou();
        if (original == copy || original.getAge() != 18 || copy.getAge() != 19) {
            throw new AssertionError("复制对象验证失败");
        }
        System.out.println();
        return original;
    }

    private static void demonstrateAccess(Person person) {
        System.out.println("Task 2：访问权限与 static");
        System.out.println("Person 内部读取 private（通过 printInfo 展示）：");
        person.printInfo();
        System.out.println("通过类名读取创建数量：" + Person.getCount());
        SamePackageAccess.show(person);
        OtherPackageAccess.show(person);
        PersonChild child = new PersonChild("小林", 20, 2);
        System.out.println("跨包子类访问 protected：" + child.inheritedName());
        System.out.println("再创建一个子类对象后，计数：" + Person.getCount());
        if (Person.getCount() != 3) {
            throw new AssertionError("静态计数验证失败");
        }
        System.out.println();
    }

    private static void demonstrateInheritance() {
        System.out.println("Task 3：继承与重写");
        Animal[] animals = {new Penguin("小企鹅", 1), new Mouse("小老鼠", 2)};
        for (Animal animal : animals) {
            animal.introduction();
            animal.eat();
            animal.sleep();
        }
        System.out.println();
    }

    private static void demonstrateShapes() {
        System.out.println("Task 4：图形多态");
        List<Shape> shapes = List.of(new Circle(2), new Rectangle(3, 4), new Triangle(3, 4, 5));
        for (Shape shape : shapes) {
            System.out.printf(Locale.ROOT, "%s：面积=%.3f，周长=%.3f%n",
                    shape.getClass().getSimpleName(), shape.area(), shape.perimeter());
        }
        if (Math.abs(shapes.get(0).area() - 4 * Math.PI) > 1e-9
                || shapes.get(1).area() != 12 || shapes.get(1).perimeter() != 14
                || shapes.get(2).area() != 6 || shapes.get(2).perimeter() != 12) {
            throw new AssertionError("图形计算验证失败");
        }
        try {
            new Triangle(1, 2, 3);
            throw new AssertionError("无效三角形未被拒绝");
        } catch (IllegalArgumentException e) {
            System.out.println("创建边长 1、2、3 的三角形：" + e.getMessage());
        }
        System.out.println();
    }

    private static void demonstrateAccounts() {
        System.out.println("Task 5：银行账户封装");
        BankAccount sender = new BankAccount("12345678", "张三", 100, "123456");
        BankAccount receiver = new BankAccount("87654321", "李四", 0, "654321");
        showBalances("初始余额", sender, receiver);
        sender.deposit(20);
        showBalances("存入20元", sender, receiver);
        boolean withdrawn = sender.withdraw(50, "123456");
        System.out.println("取出50元：" + withdrawn);
        showBalances("取款后", sender, receiver);
        boolean transferred = sender.transfer(receiver, 30, "123456");
        System.out.println("转出30元：" + transferred);
        showBalances("转账后", sender, receiver);
        checkFailure("错误密码取款", sender.withdraw(10, "wrong"), sender, receiver);
        checkFailure("余额不足取款", sender.withdraw(1000, "123456"), sender, receiver);
        checkFailure("错误密码转账", sender.transfer(receiver, 10, "wrong"), sender, receiver);
        checkFailure("余额不足转账", sender.transfer(receiver, 1000, "123456"), sender, receiver);
        checkFailure("负数取款", sender.withdraw(-10, "123456"), sender, receiver);
        checkFailure("零金额转账", sender.transfer(receiver, 0, "123456"), sender, receiver);
        checkFailure("NaN金额转账", sender.transfer(receiver, Double.NaN, "123456"), sender, receiver);
        checkFailure("空收款人", sender.transfer(null, 10, "123456"), sender, receiver);
        checkFailure("向自己转账", sender.transfer(sender, 10, "123456"), sender, receiver);
        try {
            sender.deposit(0);
            throw new AssertionError("零金额存款未被拒绝");
        } catch (IllegalArgumentException e) {
            System.out.println("零金额存款：已拒绝，余额=" + sender.getBalance());
        }
        if (!withdrawn || !transferred || sender.getBalance() != 40 || receiver.getBalance() != 30) {
            throw new AssertionError("账户操作验证失败");
        }
        System.out.println("账户信息：" + sender.getAccountInfo());
        System.out.println("全部运行检查通过");
    }

    private static void showBalances(String step, BankAccount sender, BankAccount receiver) {
        System.out.printf(Locale.ROOT, "%s：付款账户=%.2f元，收款账户=%.2f元%n",
                step, sender.getBalance(), receiver.getBalance());
    }

    private static void checkFailure(String step, boolean result, BankAccount sender, BankAccount receiver) {
        System.out.printf(Locale.ROOT, "%s：%s，两账户余额=%.2f / %.2f元%n",
                step, result, sender.getBalance(), receiver.getBalance());
        if (result || sender.getBalance() != 40 || receiver.getBalance() != 30) {
            throw new AssertionError(step + "改变了余额");
        }
    }
}
