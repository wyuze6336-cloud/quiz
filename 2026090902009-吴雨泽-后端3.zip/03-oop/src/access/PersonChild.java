package access;

import people.Person;

public class PersonChild extends Person {
    public PersonChild(String name, int age, int sex) {
        super(name, age, sex);
    }

    public String inheritedName() {
        return this.protectedName();
    }
}
