package access;

import people.Person;

public class OtherPackageAccess {
    public static void show(Person person) {
        System.out.println("跨包普通类访问 public：" + person.getName());
    }
}
