public class Mouse extends Animal {
    public Mouse(String name, int id) {
        super(name, id);
    }

    @Override
    public void eat() {
        System.out.println(getName() + "是老鼠，正在吃谷物");
    }
}
