# 快递取件码查询系统

后端第 5 题 Task 4。使用 JDK HttpServer、HttpURLConnection 和 Fastjson2，四组数据来自题面。

需要 JDK 8 或更新版本、Maven。本次验证环境为 JDK 21.0.12、Maven 3.9.9。

在此目录构建：

```bash
mvn clean package
```

两个终端分别启动服务端和客户端：

```bash
mvn exec:java -Dexec.mainClass=express.Server
```

```bash
mvn exec:java -Dexec.mainClass=express.Client
```

服务端地址：`http://127.0.0.1:8000/query`。例如输入单号 `SF123456789`、手机号 `13005433678`，返回取件码 `1234`。客户端输入 `exit` 退出，服务端用 Ctrl+C 停止。

请求必须是 POST，JSON 字段为 `trackingNumber` 和 `phone`。响应字段为 `pick_code` 和 `msg`。查询不到返回 200 和提示，格式错误返回 400；其他方法返回 405，路径不正确返回 404，请求体超过 8192 字节返回 413。

完整作答、代码说明和运行记录见压缩包根目录中的 MD、PDF 和 `后端5运行结果.txt`。服务端与客户端的真实终端截图仍需补充。
