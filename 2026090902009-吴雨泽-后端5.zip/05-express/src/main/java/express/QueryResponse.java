package express;

import com.alibaba.fastjson2.annotation.JSONField;

public class QueryResponse {
    @JSONField(name = "pick_code")
    private String pickCode;
    private String msg;

    public QueryResponse() {}

    public QueryResponse(String pickCode, String msg) {
        this.pickCode = pickCode;
        this.msg = msg;
    }

    public String getPickCode() { return pickCode; }
    public void setPickCode(String pickCode) { this.pickCode = pickCode; }
    public String getMsg() { return msg; }
    public void setMsg(String msg) { this.msg = msg; }
}
