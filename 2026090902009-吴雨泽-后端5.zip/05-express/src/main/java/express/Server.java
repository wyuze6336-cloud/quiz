package express;

import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONException;
import com.alibaba.fastjson2.JSONWriter;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.*;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

public class Server {
    private static final int PORT = 8000;
    private static final Map<String, String> expressMap = new HashMap<>();

    private static void initializeExpressData() {
        expressMap.put("SF123456789_13005433678", "1234");
        expressMap.put("JD987654321_19805433168", "5678");
        expressMap.put("YT456789123_13905479698", "9012");
        expressMap.put("ZT789123456_18505433664", "3456");
    }

    public static void main(String[] args) throws IOException {
        initializeExpressData();
        HttpServer server = HttpServer.create(
                new InetSocketAddress("127.0.0.1", PORT), 0);
        server.createContext("/query", Server::handle);
        server.start();
        System.out.println("Server started: http://127.0.0.1:" + PORT + "/query");
    }

    private static void handle(HttpExchange exchange) throws IOException {
        try {
            if (!"/query".equals(exchange.getRequestURI().getPath())) {
                send(exchange, 404, new QueryResponse(null, "接口不存在"));
                return;
            }
            if (!"POST".equals(exchange.getRequestMethod())) {
                exchange.getResponseHeaders().set("Allow", "POST");
                send(exchange, 405, new QueryResponse(null, "仅支持POST"));
                return;
            }

            QueryResponse result;
            try {
                ByteArrayOutputStream body = new ByteArrayOutputStream();
                try (InputStream in = exchange.getRequestBody()) {
                    byte[] buffer = new byte[1024];
                    int n;
                    while ((n = in.read(buffer)) != -1) {
                        if (body.size() + n > 8192) {
                            send(exchange, 413, new QueryResponse(null, "请求体过大"));
                            return;
                        }
                        body.write(buffer, 0, n);
                    }
                }
                String json = new String(body.toByteArray(), StandardCharsets.UTF_8);
                QueryRequest request = JSON.parseObject(json, QueryRequest.class);
                if (request == null || request.getTrackingNumber() == null
                        || request.getPhone() == null) {
                    throw new IllegalArgumentException();
                }
                String number = request.getTrackingNumber().trim();
                String phone = request.getPhone().trim();
                if (number.isEmpty() || phone.isEmpty()) {
                    throw new IllegalArgumentException();
                }
                String code = expressMap.get(number + "_" + phone);
                result = new QueryResponse(code,
                        code == null ? "单号或手机号不正确" : "success");
            } catch (JSONException | IllegalArgumentException ex) {
                send(exchange, 400, new QueryResponse(null, "请求格式错误"));
                return;
            }
            send(exchange, 200, result);
        } finally {
            exchange.close();
        }
    }

    private static void send(HttpExchange exchange, int status,
                             QueryResponse result) throws IOException {
        String json = JSON.toJSONString(result, JSONWriter.Feature.WriteNulls);
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        exchange.sendResponseHeaders(status, bytes.length);
        try (OutputStream out = exchange.getResponseBody()) {
            out.write(bytes);
        }
    }
}
