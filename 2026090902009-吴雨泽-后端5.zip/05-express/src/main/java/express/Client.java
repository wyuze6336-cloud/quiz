package express;

import com.alibaba.fastjson2.JSON;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Client {
    private static final String SERVER_URL = "http://127.0.0.1:8000/query";

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            while (true) {
                System.out.print("请输入快递单号（exit退出）: ");
                if (!scanner.hasNextLine()) break;
                String number = scanner.nextLine().trim();
                if ("exit".equalsIgnoreCase(number)) break;

                System.out.print("请输入手机号: ");
                if (!scanner.hasNextLine()) break;
                String phone = scanner.nextLine().trim();
                HttpURLConnection connection = null;
                try {
                    QueryRequest request = new QueryRequest(number, phone);
                    byte[] bytes = JSON.toJSONString(request).getBytes(StandardCharsets.UTF_8);
                    connection = (HttpURLConnection) new URL(SERVER_URL).openConnection();
                    connection.setConnectTimeout(5000);
                    connection.setReadTimeout(5000);
                    connection.setRequestMethod("POST");
                    connection.setDoOutput(true);
                    connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                    connection.setFixedLengthStreamingMode(bytes.length);
                    try (OutputStream out = connection.getOutputStream()) {
                        out.write(bytes);
                    }

                    int status = connection.getResponseCode();
                    InputStream stream = status < 400
                            ? connection.getInputStream() : connection.getErrorStream();
                    String body = readBody(stream);
                    if (status == 200) {
                        QueryResponse response = JSON.parseObject(body, QueryResponse.class);
                        System.out.println(response.getPickCode() == null
                                ? response.getMsg() : "取件码: " + response.getPickCode());
                    } else {
                        System.out.println("HTTP " + status + ": " + body);
                    }
                } catch (IOException | RuntimeException ex) {
                    System.err.println("查询失败: " + ex.getMessage());
                } finally {
                    if (connection != null) connection.disconnect();
                }
            }
        }
        System.out.println("客户端已退出");
    }

    private static String readBody(InputStream stream) throws IOException {
        if (stream == null) return "";
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            StringBuilder body = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                body.append(line);
            }
            return body.toString();
        }
    }
}
