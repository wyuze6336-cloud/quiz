package express;

public class QueryRequest {
    private String trackingNumber;
    private String phone;

    public QueryRequest() {}

    public QueryRequest(String trackingNumber, String phone) {
        this.trackingNumber = trackingNumber;
        this.phone = phone;
    }

    public String getTrackingNumber() { return trackingNumber; }
    public void setTrackingNumber(String trackingNumber) {
        this.trackingNumber = trackingNumber;
    }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
}
