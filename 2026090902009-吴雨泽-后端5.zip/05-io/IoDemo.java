import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class IoDemo {
    public static void copyImage() throws IOException {
        File source = new File("doro.jpg");
        File target = new File("doro_copy.jpg");
        try (InputStream in = new FileInputStream(source);
             OutputStream out = new FileOutputStream(target)) {
            byte[] buffer = new byte[1024];
            int n;
            while ((n = in.read(buffer)) != -1) {
                out.write(buffer, 0, n);
            }
        }
        System.out.println("图片复制完成：doro_copy.jpg");
    }

    public static void sortNames() throws IOException {
        List<String> names = new ArrayList<>();
        try (BufferedReader in = new BufferedReader(new InputStreamReader(
                new FileInputStream("name.txt"), StandardCharsets.UTF_8))) {
            String line;
            while ((line = in.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty()) {
                    names.add(line);
                }
            }
        }
        Collections.sort(names);
        try (BufferedWriter out = new BufferedWriter(new OutputStreamWriter(
                new FileOutputStream("name_sorted.txt"), StandardCharsets.UTF_8))) {
            for (String name : names) {
                out.write(name);
                out.newLine();
            }
        }
        System.out.println("姓名排序结果：");
        names.forEach(System.out::println);
    }

    public static class Student implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer id;
        private String name;
        private Integer gender;
        private String phone;

        public Student(Integer id, String name, Integer gender, String phone) {
            this.id = id;
            this.name = name;
            this.gender = gender;
            this.phone = phone;
        }

        public Integer getId() { return id; }
        public void setId(Integer id) { this.id = id; }
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public Integer getGender() { return gender; }
        public void setGender(Integer gender) { this.gender = gender; }
        public String getPhone() { return phone; }
        public void setPhone(String phone) { this.phone = phone; }

        @Override
        public String toString() {
            return "Student{id=" + id + ", name='" + name + "', gender=" + gender
                    + ", phone='" + phone + "'}";
        }
    }

    public static void serialize() throws IOException, ClassNotFoundException {
        Student student = new Student(1, "doro", 2, "114514");
        try (ObjectOutputStream out = new ObjectOutputStream(
                new FileOutputStream("student.dat"))) {
            out.writeObject(student);
        }
        // 写入流关闭以后，再读取同一个文件。
        try (ObjectInputStream in = new ObjectInputStream(
                new FileInputStream("student.dat"))) {
            Student doro = (Student) in.readObject();
            System.out.println("反序列化结果：" + doro);
        }
    }

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        copyImage();
        sortNames();
        serialize();
    }
}
