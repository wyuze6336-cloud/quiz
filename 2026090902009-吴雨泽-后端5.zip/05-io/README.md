# 后端第 5 题：IO 流与项目挑战

学号：2026090902009　姓名：吴雨泽

题目：[IO 流与项目挑战](https://www.glimmer.org.cn/backend/5/)

## Task 1：字节流和字符流

### Q1：复制 doro.jpg

图片不是普通文本，复制时不需要把数据转换成字符。我用 `File` 表示源文件和目标文件，再通过 `FileInputStream` 读取图片、`FileOutputStream` 写出副本。

按照题目要求，缓冲区设为 1024 字节。循环中最需要注意的是 `read` 的返回值：它表示这一次真正读到了多少字节，返回 `-1` 才表示文件读完了。所以写出时用 `write(buffer, 0, n)`，不能每次都把整个数组写进去。尤其是最后一块不足 1024 字节时，后面可能还留着上一次读入的数据。

```java
File source = new File("doro.jpg");
File target = new File("doro_copy.jpg");
try (InputStream in = new FileInputStream(source);
     OutputStream out = new FileOutputStream(target)) {
    byte[] buffer = new byte[1024];
    int n;
    while ((n = in.read(buffer)) != -1) {
        out.write(buffer, 0, n);
    }
}
```

这里先打开输入流，再打开输出流，复制结束后先关闭输出流，再关闭输入流。`try-with-resources` 会按声明的逆序关闭资源；即使中间发生异常，也会执行关闭操作，不需要在每个分支中重复写 `close()`。

这段程序没有对图片内容进行解码，也没有重新压缩图片。验证时，除了检查副本能否打开，我还比较了两个文件的 SHA-256 和原始字节，确认复制前后完全一致。结果记录在压缩包的 `后端5运行结果.txt` 中。

### Q2：读取、清理并排序姓名

这次处理的是文本，需要先按 UTF-8 把文件里的字节解码成字符。输入端使用 `FileInputStream → InputStreamReader → BufferedReader`，输出端对应使用 `FileOutputStream → OutputStreamWriter → BufferedWriter`。

我的处理顺序是：逐行读取，去掉首尾空格，跳过空行，把剩下的姓名加入列表，然后调用 `Collections.sort` 排序。最后把每个姓名单独写成一行。题目只要求排序，没有要求去重，因此相同姓名仍然保留。

```java
List<String> names = new ArrayList<>();
try (BufferedReader in = new BufferedReader(new InputStreamReader(
        new FileInputStream("name.txt"), StandardCharsets.UTF_8))) {
    String line;
    while ((line = in.readLine()) != null) {
        line = line.trim();
        if (!line.isEmpty()) {
            names.add(line);
        }
    }
}
Collections.sort(names);
try (BufferedWriter out = new BufferedWriter(new OutputStreamWriter(
        new FileOutputStream("name_sorted.txt"), StandardCharsets.UTF_8))) {
    for (String name : names) {
        out.write(name);
        out.newLine();
    }
}
```

`readLine()` 读到文件末尾时返回 `null`，和字节流的 `-1` 不同。读取过程中先清理再排序，可以避免姓名前的空格影响排序结果。

这里的自然排序不是按拼音排序。Java 的字符串比较按 UTF-16 代码单元进行字典序比较；本题中的常见汉字都在基本多文种平面内，所以这个结果符合题目要求的 Unicode 自然顺序。

我用 `newLine()` 换行，是因为它会采用当前系统的换行符。在 macOS 上通常是 `\n`，Windows 上通常是 `\r\n`。手写 `\n` 并不是一定不能用，但 `newLine()` 更适合题目强调的跨平台文本处理。

输出的 `name_sorted.txt` 内容为：

```text
冯十三
卫十六
吴十
周八
孙七
张三
李四
杨二十
沈十八
王五
王十二
蒋十七
褚十五
赵六
郑十一
钱九
陈十四
韩十九
```

验证结果是 18 行，没有空行，每行也没有多余的首尾空白。

## Task 2：序列化和反序列化

### Q3：保存并恢复 Student 对象

前面的复制程序只是在搬运字节。这一部分要保存的是对象，因此我让 `Student` 实现 `Serializable`，再使用对象流保存它的字段数据。这个接口本身没有需要实现的方法，它用来标记该类的对象可以序列化。

`serialVersionUID` 用于序列化版本兼容性检查，不是学生的学号，也不是对象的编号。

```java
public static class Student implements Serializable {
    private static final long serialVersionUID = 1L;
    // 其余字段、构造方法和 getter/setter 见后面的完整代码。
}
```

保存时创建题目要求的对象，写入 `student.dat`。等输出流关闭后，再打开输入流读取，并把返回的对象转换为 `Student`，赋给变量 `doro`。

```java
Student student = new Student(1, "doro", 2, "114514");
try (ObjectOutputStream out = new ObjectOutputStream(
        new FileOutputStream("student.dat"))) {
    out.writeObject(student);
}
try (ObjectInputStream in = new ObjectInputStream(
        new FileInputStream("student.dat"))) {
    Student doro = (Student) in.readObject();
    System.out.println(doro);
}
```

两个流操作的是同一个文件，因此不能在写入还没完成时就开始读取。将写和读分成两个 `try` 块，执行顺序会更清楚。

运行结果：

```text
反序列化结果：Student{id=1, name='doro', gender=2, phone='114514'}
```

`doro` 是从文件恢复出来的新对象，字段值与原来的对象一致。`student.dat` 保存的是序列化数据，不是 `toString()` 返回的那段文本；`toString()` 只是方便查看恢复后的对象信息。

### IO 部分的完整代码与运行方法

Q1、Q2、Q3 合并在 `05-io/IoDemo.java` 中，下面是完整代码。

```java
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class IoDemo {
    public static void copyImage() throws IOException {
        File source = new File("doro.jpg");
        File target = new File("doro_copy.jpg");
        try (InputStream in = new FileInputStream(source);
             OutputStream out = new FileOutputStream(target)) {
            byte[] buffer = new byte[1024];
            int n;
            while ((n = in.read(buffer)) != -1) {
                out.write(buffer, 0, n);
            }
        }
        System.out.println("图片复制完成：doro_copy.jpg");
    }

    public static void sortNames() throws IOException {
        List<String> names = new ArrayList<>();
        try (BufferedReader in = new BufferedReader(new InputStreamReader(
                new FileInputStream("name.txt"), StandardCharsets.UTF_8))) {
            String line;
            while ((line = in.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty()) {
                    names.add(line);
                }
            }
        }
        Collections.sort(names);
        try (BufferedWriter out = new BufferedWriter(new OutputStreamWriter(
                new FileOutputStream("name_sorted.txt"), StandardCharsets.UTF_8))) {
            for (String name : names) {
                out.write(name);
                out.newLine();
            }
        }
        System.out.println("姓名排序结果：");
        names.forEach(System.out::println);
    }

    public static class Student implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer id;
        private String name;
        private Integer gender;
        private String phone;

        public Student(Integer id, String name, Integer gender, String phone) {
            this.id = id;
            this.name = name;
            this.gender = gender;
            this.phone = phone;
        }

        public Integer getId() { return id; }
        public void setId(Integer id) { this.id = id; }
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public Integer getGender() { return gender; }
        public void setGender(Integer gender) { this.gender = gender; }
        public String getPhone() { return phone; }
        public void setPhone(String phone) { this.phone = phone; }

        @Override
        public String toString() {
            return "Student{id=" + id + ", name='" + name + "', gender=" + gender
                    + ", phone='" + phone + "'}";
        }
    }

    public static void serialize() throws IOException, ClassNotFoundException {
        Student student = new Student(1, "doro", 2, "114514");
        try (ObjectOutputStream out = new ObjectOutputStream(
                new FileOutputStream("student.dat"))) {
            out.writeObject(student);
        }
        // 写入流关闭以后，再读取同一个文件。
        try (ObjectInputStream in = new ObjectInputStream(
                new FileInputStream("student.dat"))) {
            Student doro = (Student) in.readObject();
            System.out.println("反序列化结果：" + doro);
        }
    }

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        copyImage();
        sortNames();
        serialize();
    }
}
```

在 `05-io` 目录运行，保证 `doro.jpg` 和 `name.txt` 就在当前目录：

```bash
mkdir -p build
javac -encoding UTF-8 -d build IoDemo.java
java -cp build IoDemo
```

|文件|作用|
|---|---|
|`IoDemo.java`|三个小任务的源代码|
|`doro.jpg`、`name.txt`|题目输入文件|
|`doro_copy.jpg`|按字节复制得到的图片|
|`name_sorted.txt`|清理并排序后的姓名表|
|`student.dat`|保存 Student 对象的序列化文件|
|`build/` 下的 `.class`|编译后供 JVM 执行的字节码|

## Task 3：Maven

### Maven 与 JAR 的关系

前三个小任务只用到了 JDK 提供的类，直接 `javac` 就能编译。快递项目用到了 Fastjson2，如果仍然手动编译，就需要自己准备依赖 JAR，再配置编译和运行时的类路径。Maven 可以把这些步骤按项目配置统一起来。

JAR 是把 Java 的类文件和资源打包在一起的文件。Maven 是构建工具，既可以下载项目依赖的 JAR，也可以把本项目编译、测试并打包成 JAR。两者的关系可以从本题直接看到：Fastjson2 是被下载的依赖，`express-query-1.0.0.jar` 是项目打包生成的产物。

这也解释了为什么要用 Maven：把依赖坐标、版本和构建方式写进 `pom.xml` 后，换一台电脑也能按同样的命令构建，不必逐个寻找和复制依赖文件。

### 本次验证使用的环境

本次在 macOS 上使用 JDK 21.0.12 和 Maven 3.9.9。Maven 解压到工作目录，构建时通过它的 `bin/mvn` 执行，没有修改系统的永久环境变量。

`mvn -version` 的主要输出如下：

```text
Apache Maven 3.9.9
Java version: 21.0.12, vendor: Oracle Corporation
OS name: "mac os x", arch: "aarch64", family: "mac"
```

如果希望在任意目录直接输入 `mvn`，可以把实际安装目录的 `bin` 加入 `PATH`。macOS 的临时配置方式如下，路径需要替换为自己的 Maven 安装目录：

```bash
export JAVA_HOME=$(/usr/libexec/java_home -v 21)
export PATH="/你的实际目录/apache-maven-3.9.9/bin:$PATH"
mvn -version
```

`JAVA_HOME` 指向 JDK 根目录，供 Maven 选择运行的 Java 环境；`PATH` 让终端能够找到 `mvn`。需要持久生效时，可以把配置放进 `~/.zshrc` 并重新加载。

### 本地仓库、远程仓库和私服

本地仓库保存已经下载的依赖，也可以存放通过 `mvn install` 安装的本项目产物。它默认位于 `~/.m2/repository`，不是源码目录下的 `target`。

要永久修改本地仓库位置，可以在 `~/.m2/settings.xml` 中设置：

```xml
<settings>
    <localRepository>/Users/wyz/maven-repository</localRepository>
</settings>
```

本次验证采用命令参数 `-Dmaven.repo.local=实际目录` 指定独立缓存，没有改动用户的全局设置。

本地没有所需依赖时，Maven 会尝试从配置的远程仓库获取。Maven Central 是常用的公共中央仓库。私服则是组织自己维护的仓库，可以托管内部依赖，也可以代理并缓存公共仓库中的包。

### pom.xml 和项目结构

本项目的坐标是 `cn.glimmer.reference:express-query:1.0.0`。`groupId` 表示组织或项目分组，`artifactId` 是项目名称，`version` 是版本。`packaging` 没有显式写出时，默认按 JAR 项目处理。

`properties` 中设置源码编码和编译目标，`dependencies` 中声明 Fastjson2，`build/plugins` 中配置编译插件和执行插件。项目采用 JDK 21 构建，`maven.compiler.release` 设置为 8，代码也避免使用 `readAllBytes()` 等较新的 API。

```text
05-express/
├── pom.xml
├── README.md
├── src/
│   ├── main/
│   │   ├── java/express/        四个 Java 类
│   │   └── resources/           配置和资源的约定位置
│   └── test/
│       ├── java/                测试代码的约定位置
│       └── resources/           测试资源的约定位置
└── target/                      编译和打包产物
```

本项目暂时没有资源文件和独立的测试类，所以对应的空目录没有放入压缩包；接口验证采用实际 HTTP 请求完成。

完整 `pom.xml` 如下：

```xml
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>
    <groupId>cn.glimmer.reference</groupId>
    <artifactId>express-query</artifactId>
    <version>1.0.0</version>
    <properties>
        <maven.compiler.release>8</maven.compiler.release>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
    </properties>
    <dependencies>
        <dependency>
            <groupId>com.alibaba.fastjson2</groupId>
            <artifactId>fastjson2</artifactId>
            <version>2.0.51</version>
        </dependency>
    </dependencies>
    <build>
        <plugins>
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-compiler-plugin</artifactId>
                <version>3.13.0</version>
            </plugin>
            <plugin>
                <groupId>org.codehaus.mojo</groupId>
                <artifactId>exec-maven-plugin</artifactId>
                <version>3.5.0</version>
            </plugin>
        </plugins>
    </build>
</project>
```

这里有一个题面容易混淆的地方：依赖示例写的是 `com.alibaba:fastjson:2.0.51`，但 Java 示例导入的是 `com.alibaba.fastjson2.JSON`。本项目统一使用 `com.alibaba.fastjson2:fastjson2:2.0.51`，使依赖和导入的包名对应。

### 常用命令与 IDEA

|命令|作用|
|---|---|
|`mvn clean`|清理上次构建生成的 `target`|
|`mvn compile`|编译主程序|
|`mvn test`|执行测试阶段|
|`mvn package`|完成前置阶段后打包|
|`mvn verify`|执行到验证阶段|
|`mvn install`|把本项目产物安装到本地仓库|

`package` 会先完成编译和测试等前置阶段，所以不需要先手动执行一遍 `compile`。本次项目没有测试类，构建成功只能说明编译和打包通过，不能代替接口运行验证。

在 IDEA 中打开 `pom.xml` 所在目录后，可以加载 Maven 项目。在 Maven 设置中选择 Maven home、用户 `settings.xml`、本地仓库和运行 JDK，尽量与终端使用的配置一致。Maven 面板中的 Lifecycle 可以执行 `clean`、`compile`、`test`、`package`、`install` 等阶段，Plugins 中可以执行插件目标。

本次完成的是命令行构建和运行验证，尚未附 IDEA 关联 Maven 的实操记录。

## Task 4：快递取件码查询系统

### 实现思路

这个系统分成客户端和服务端。客户端负责收集单号和手机号，再把请求发给服务端；服务端负责校验数据、查表，并返回结果。查询数据放在服务端的 `Map` 中，客户端没有直接访问这张表。

|类|本项目中的职责|
|---|---|
|`Server`|监听 8000 端口，处理 `/query` 请求|
|`Client`|读取输入，发送 HTTP 请求并展示结果|
|`QueryRequest`|保存请求中的 `trackingNumber` 和 `phone`|
|`QueryResponse`|保存响应中的 `pick_code` 和 `msg`|

一次查询的过程是：输入单号和手机号 → 请求对象转成 JSON → POST 到 `/query` → 服务端解析 JSON 并查表 → 响应对象转成 JSON → 客户端解析并打印。

例如，查询第一组数据时发送：

```json
{"trackingNumber":"SF123456789","phone":"13005433678"}
```

服务端用 `SF123456789_13005433678` 作为键查询，找到后返回：

```json
{"pick_code":"1234","msg":"success"}
```

取件码使用字符串，而不是整数，避免未来出现 `0012` 这样的取件码时丢失前面的零。Java 字段采用 `pickCode`，通过 `@JSONField(name = "pick_code")` 对应题目规定的 JSON 属性。

### HTTP、JSON 与 TCP/IP 在这里做了什么

HTTP 规定请求方法、路径、状态码和报文格式，本项目使用 POST 发送查询数据。JSON 只是请求体和响应体的数据格式，Fastjson2 负责 Java 对象与 JSON 文本之间的转换。底层 TCP 连接承载这些 HTTP 数据，`HttpURLConnection` 和 `HttpServer` 处理连接及报文的读写。

常见方法中，GET 通常用于读取资源，POST 用于提交数据，PUT 用于替换资源，DELETE 用于删除资源。本项目按题面只接受 POST。200 表示请求已正常处理，400 表示请求格式有问题，404 表示路径不存在，405 表示该接口不接受这种请求方法；500 通常表示服务端发生内部错误。

我把“没查到快递”和“请求格式错误”分开处理：单号和手机号都有值，只是组合不在表里，属于一次正常完成但没有匹配结果的查询，返回 200 和提示信息；JSON 损坏或必填字段为空，则返回 400。

### 服务端完整代码：Server.java

```java
package express;

import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONException;
import com.alibaba.fastjson2.JSONWriter;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.*;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

public class Server {
    private static final int PORT = 8000;
    private static final Map<String, String> expressMap = new HashMap<>();

    private static void initializeExpressData() {
        expressMap.put("SF123456789_13005433678", "1234");
        expressMap.put("JD987654321_19805433168", "5678");
        expressMap.put("YT456789123_13905479698", "9012");
        expressMap.put("ZT789123456_18505433664", "3456");
    }

    public static void main(String[] args) throws IOException {
        initializeExpressData();
        HttpServer server = HttpServer.create(
                new InetSocketAddress("127.0.0.1", PORT), 0);
        server.createContext("/query", Server::handle);
        server.start();
        System.out.println("Server started: http://127.0.0.1:" + PORT + "/query");
    }

    private static void handle(HttpExchange exchange) throws IOException {
        try {
            if (!"/query".equals(exchange.getRequestURI().getPath())) {
                send(exchange, 404, new QueryResponse(null, "接口不存在"));
                return;
            }
            if (!"POST".equals(exchange.getRequestMethod())) {
                exchange.getResponseHeaders().set("Allow", "POST");
                send(exchange, 405, new QueryResponse(null, "仅支持POST"));
                return;
            }

            QueryResponse result;
            try {
                ByteArrayOutputStream body = new ByteArrayOutputStream();
                try (InputStream in = exchange.getRequestBody()) {
                    byte[] buffer = new byte[1024];
                    int n;
                    while ((n = in.read(buffer)) != -1) {
                        if (body.size() + n > 8192) {
                            send(exchange, 413, new QueryResponse(null, "请求体过大"));
                            return;
                        }
                        body.write(buffer, 0, n);
                    }
                }
                String json = new String(body.toByteArray(), StandardCharsets.UTF_8);
                QueryRequest request = JSON.parseObject(json, QueryRequest.class);
                if (request == null || request.getTrackingNumber() == null
                        || request.getPhone() == null) {
                    throw new IllegalArgumentException();
                }
                String number = request.getTrackingNumber().trim();
                String phone = request.getPhone().trim();
                if (number.isEmpty() || phone.isEmpty()) {
                    throw new IllegalArgumentException();
                }
                String code = expressMap.get(number + "_" + phone);
                result = new QueryResponse(code,
                        code == null ? "单号或手机号不正确" : "success");
            } catch (JSONException | IllegalArgumentException ex) {
                send(exchange, 400, new QueryResponse(null, "请求格式错误"));
                return;
            }
            send(exchange, 200, result);
        } finally {
            exchange.close();
        }
    }

    private static void send(HttpExchange exchange, int status,
                             QueryResponse result) throws IOException {
        String json = JSON.toJSONString(result, JSONWriter.Feature.WriteNulls);
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        exchange.sendResponseHeaders(status, bytes.length);
        try (OutputStream out = exchange.getResponseBody()) {
            out.write(bytes);
        }
    }
}
```

服务端先检查路径和方法，再读取请求体。解析后检查两个字段是否存在、是否为空，然后拼接键并查询。成功与查询不到都构造 `QueryResponse`，通过统一的 `send` 方法返回。

写响应时显式使用 `WriteNulls`，这样查询不到时仍会返回题目要求的 `"pick_code":null`。响应长度按 UTF-8 编码后的字节数计算，中文字符不能简单按 `String.length()` 计算报文长度。

本项目只在 `127.0.0.1` 上监听，适合在同一台电脑的两个终端中练习。额外限制请求体不超过 8192 字节；题面的正常查询远小于这个限制。

### 客户端完整代码：Client.java

```java
package express;

import com.alibaba.fastjson2.JSON;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Client {
    private static final String SERVER_URL = "http://127.0.0.1:8000/query";

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            while (true) {
                System.out.print("请输入快递单号（exit退出）: ");
                if (!scanner.hasNextLine()) break;
                String number = scanner.nextLine().trim();
                if ("exit".equalsIgnoreCase(number)) break;

                System.out.print("请输入手机号: ");
                if (!scanner.hasNextLine()) break;
                String phone = scanner.nextLine().trim();
                HttpURLConnection connection = null;
                try {
                    QueryRequest request = new QueryRequest(number, phone);
                    byte[] bytes = JSON.toJSONString(request).getBytes(StandardCharsets.UTF_8);
                    connection = (HttpURLConnection) new URL(SERVER_URL).openConnection();
                    connection.setConnectTimeout(5000);
                    connection.setReadTimeout(5000);
                    connection.setRequestMethod("POST");
                    connection.setDoOutput(true);
                    connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                    connection.setFixedLengthStreamingMode(bytes.length);
                    try (OutputStream out = connection.getOutputStream()) {
                        out.write(bytes);
                    }

                    int status = connection.getResponseCode();
                    InputStream stream = status < 400
                            ? connection.getInputStream() : connection.getErrorStream();
                    String body = readBody(stream);
                    if (status == 200) {
                        QueryResponse response = JSON.parseObject(body, QueryResponse.class);
                        System.out.println(response.getPickCode() == null
                                ? response.getMsg() : "取件码: " + response.getPickCode());
                    } else {
                        System.out.println("HTTP " + status + ": " + body);
                    }
                } catch (IOException | RuntimeException ex) {
                    System.err.println("查询失败: " + ex.getMessage());
                } finally {
                    if (connection != null) connection.disconnect();
                }
            }
        }
        System.out.println("客户端已退出");
    }

    private static String readBody(InputStream stream) throws IOException {
        if (stream == null) return "";
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            StringBuilder body = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                body.append(line);
            }
            return body.toString();
        }
    }
}
```

客户端先判断 `exit`，所以退出时不需要继续输入手机号。正常查询时，先序列化请求对象，再按 UTF-8 写入连接的输出流。

拿到响应后，状态码为 200 就解析 `QueryResponse`，有取件码则显示取件码，没有则显示 `msg`。非 200 的响应通过错误流读取，输出状态码和服务端提示。连接放在 `finally` 中断开，即使查询发生异常也不会漏掉清理。

### 请求类完整代码：QueryRequest.java

```java
package express;

public class QueryRequest {
    private String trackingNumber;
    private String phone;

    public QueryRequest() {}

    public QueryRequest(String trackingNumber, String phone) {
        this.trackingNumber = trackingNumber;
        this.phone = phone;
    }

    public String getTrackingNumber() { return trackingNumber; }
    public void setTrackingNumber(String trackingNumber) {
        this.trackingNumber = trackingNumber;
    }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
}
```

### 响应类完整代码：QueryResponse.java

```java
package express;

import com.alibaba.fastjson2.annotation.JSONField;

public class QueryResponse {
    @JSONField(name = "pick_code")
    private String pickCode;
    private String msg;

    public QueryResponse() {}

    public QueryResponse(String pickCode, String msg) {
        this.pickCode = pickCode;
        this.msg = msg;
    }

    public String getPickCode() { return pickCode; }
    public void setPickCode(String pickCode) { this.pickCode = pickCode; }
    public String getMsg() { return msg; }
    public void setMsg(String msg) { this.msg = msg; }
}
```

### 构建与运行方法

在 `05-express` 目录中，先执行：

```bash
mvn clean package
```

然后打开两个终端，两个终端都进入 `05-express` 目录。

终端一启动服务端：

```bash
mvn exec:java -Dexec.mainClass=express.Server
```

终端二启动客户端：

```bash
mvn exec:java -Dexec.mainClass=express.Client
```

客户端输入 `exit` 退出；服务端用 `Ctrl+C` 停止。注意，`mvn package` 生成的普通 JAR 默认不包含 Fastjson2 依赖，也没有指定启动入口，因此这里使用 `exec:java` 按项目类路径运行。

### 实际运行结果

本次构建结果为 `BUILD SUCCESS`，四组题面数据全部查到了对应取件码：

|单号|手机号|返回取件码|
|---|---|---|
|SF123456789|13005433678|1234|
|JD987654321|19805433168|5678|
|YT456789123|13905479698|9012|
|ZT789123456|18505433664|3456|

客户端的实际输出及接口验证记录如下：

```text
请输入快递单号（exit退出）: 请输入手机号: 取件码: 1234
请输入快递单号（exit退出）: 请输入手机号: 取件码: 5678
请输入快递单号（exit退出）: 请输入手机号: 取件码: 9012
请输入快递单号（exit退出）: 请输入手机号: 取件码: 3456
请输入快递单号（exit退出）: 请输入手机号: 单号或手机号不正确
请输入快递单号（exit退出）: 客户端已退出
```

除了正确查询，还验证了以下情况：

|输入情况|HTTP 状态|响应结果|
|---|---:|---|
|单号和手机号组合不存在|200|`pick_code=null`，提示单号或手机号不正确|
|单号为空、缺少手机号或请求体为 `null`|400|请求格式错误|
|请求体不是合法 JSON|400|请求格式错误|
|用 GET 请求 `/query`|405|仅支持 POST|
|请求 `/query/other`|404|接口不存在|
|请求体超过 8192 字节|413|请求体过大|

服务端停止后，再运行客户端，实际出现连接拒绝提示，程序仍继续等待输入，输入 `exit` 可以正常结束。完整记录见 `后端5运行结果.txt`，原始 Maven 构建日志见 `后端5-Maven构建日志.txt`。

### 终端运行截图

下面是 macOS 终端的实际运行截图，包含图片复制与哈希比较、姓名排序、反序列化、Maven 构建以及服务端和客户端的运行结果。快递查询部分由脚本依次输入四组题面数据、一个错误组合和 `exit`，分别得到四个取件码、错误提示和正常退出信息。

![第五题终端运行结果](后端5截图/终端运行结果.png)

## 思考与记录

文件复制和 HTTP 通信看起来是两个任务，但代码中用到的是同一种基本操作：从输入流读到字节，再把这些字节写到输出流。区别在于文件复制直接保留字节，文本和 JSON 则需要在字节与字符之间按约定编码进行转换。这也是客户端、服务端都显式使用 UTF-8 的原因。

核对项目时，依赖示例与导入包名不一致是一个具体问题。解决方式是先看代码实际需要哪个包，再统一 Maven 坐标，而不是只看依赖名称相似就照抄。依赖能成功下载以后，还需要实际编译，才能确认代码确实能引用这些类。

另一个需要区分的地方是“构建通过”和“功能正确”。Maven 打包通过以后，我又运行了服务端和客户端，逐组检查查询结果，再测试空字段和错误方法。只看到 `BUILD SUCCESS`，并不能判断单号是否录入正确，也不能判断错误请求会得到什么响应。

现阶段的数据是写在 `Map` 中的，服务端重启后仍然只加载这四组固定数据，没有数据库，也没有真正调用快递平台接口。它完成的是题目要求的查询练习。后续如果增加录入、删除或更新快递数据，还需要继续考虑持久化以及不同用户的访问权限。

参考资料：[Maven 官方入门](https://maven.apache.org/guides/getting-started/)、[Maven 标准目录结构](https://maven.apache.org/guides/introduction/introduction-to-the-standard-directory-layout.html)。
