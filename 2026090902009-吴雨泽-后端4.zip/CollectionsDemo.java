import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.function.Consumer;

public class CollectionsDemo {
    public interface Repository<T> {
        int save(T value);
        T getById(int id);
    }

    public static class MyRepository<T> implements Repository<T> {
        private final Map<Integer, T> data = new LinkedHashMap<>();
        private int nextId = 0;

        @Override
        public int save(T value) {
            Objects.requireNonNull(value, "value must not be null");
            if (nextId == Integer.MAX_VALUE) {
                throw new IllegalStateException("ID exhausted");
            }
            int id = nextId++;
            data.put(id, value);
            return id;
        }

        @Override
        public T getById(int id) {
            if (!data.containsKey(id)) {
                throw new NoSuchElementException("Unknown ID: " + id);
            }
            return data.get(id);
        }

        public void forEach(Consumer<? super T> action) {
            data.values().forEach(action);
        }
    }

    public static class User {
        private final String name;
        private final int age;

        public User(String name, int age) {
            this.name = name;
            this.age = age;
        }

        @Override
        public String toString() {
            return "User{name='" + name + "', age=" + age + "}";
        }
    }

    public enum CharacterType {
        SABER, ARCHER, CASTER
    }

    public interface Character {
        void attack();
    }

    public static class Saber implements Character {
        @Override
        public void attack() {
            System.out.println("[剑士] 阿尔托莉雅 使用 Excalibur 发动攻击！");
        }
    }

    public static class Archer implements Character {
        @Override
        public void attack() {
            System.out.println("[弓兵] 卫宫 使用 Unlimited Blade Works 发动攻击！");
        }
    }

    public static class Caster implements Character {
        @Override
        public void attack() {
            System.out.println("[法师] 美狄亚 使用 Rho Aias 发动攻击！");
        }
    }

    public static class CharacterFactory {
        public static Character create(CharacterType type) {
            if (type == null) {
                throw new IllegalArgumentException("Character type must not be null");
            }
            switch (type) {
                case SABER:
                    return new Saber();
                case ARCHER:
                    return new Archer();
                case CASTER:
                    return new Caster();
                default:
                    throw new IllegalArgumentException("Unknown type: " + type);
            }
        }
    }

    private static void traversalDemo() {
        List<Integer> list = new ArrayList<>();
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);

        System.out.println("Q2: enhanced for");
        for (Integer number : list) {
            System.out.println(number);
        }

        System.out.println("Q3: lambda");
        list.forEach(number -> System.out.println(number));

        System.out.println("Iterator");
        Iterator<Integer> iterator = list.iterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }
    }

    private static void repositoryDemo() {
        MyRepository<String> strings = new MyRepository<>();
        strings.save("hello");
        strings.save("glimmer");

        MyRepository<User> users = new MyRepository<>();
        int aliceId = users.save(new User("Alice", 18));
        users.save(new User("Bob", 20));

        MyRepository<Integer> numbers = new MyRepository<>();
        numbers.save(10);
        numbers.save(20);

        System.out.println("String repository");
        strings.forEach(System.out::println);
        System.out.println("User repository");
        users.forEach(System.out::println);
        System.out.println("Integer repository");
        numbers.forEach(System.out::println);
        System.out.println("getById(" + aliceId + "): " + users.getById(aliceId));
    }

    private static void factoryDemo() {
        Character saber = CharacterFactory.create(CharacterType.SABER);
        Character archer = CharacterFactory.create(CharacterType.ARCHER);
        Character caster = CharacterFactory.create(CharacterType.CASTER);
        saber.attack();
        archer.attack();
        caster.attack();
    }

    public static void main(String[] args) {
        String section = args.length == 0 ? "all" : args[0];
        switch (section) {
            case "traversal":
                traversalDemo();
                break;
            case "repository":
                repositoryDemo();
                break;
            case "factory":
                factoryDemo();
                break;
            case "all":
                traversalDemo();
                repositoryDemo();
                factoryDemo();
                break;
            default:
                throw new IllegalArgumentException("Use traversal, repository, factory or all");
        }
    }
}
